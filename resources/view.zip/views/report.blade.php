@extends('layouts.app')
@section('title','Honest | Home ')
@section('content')
    <div class="flex h-screen divide-x-2 divide-gray-100 ">
        <!-- Sidebar -->
        @include('common.sidenav')
       

        <!-- Main Content -->
        <div class="main-content flex-1 ml-64 transition-all duration-300">
            <!-- Welcome Section -->
           @include('common.header')

            <!-- Table Section -->
            <div class="p-5 bg-white">

              
               
                <form>
            <div class="grid md:grid-cols-4 lg:grid-cols-5 gap-4 divide-x">
                @if($report)
                @foreach ($report as $report)
                    
                <div class="md:col-span-2  ">
                    <h5 class="px-4 pt-1 pb-2 text-xl font-semibold">Report</h5>
                    <div class="bg-gray-100 rounded-lg p-4">
                        <div class="flex gap-4 h-14 items-center">
                            {{-- <div class="w-20 flex relative h-14">
                                <div class="w-14 h-14 rounded-full  me-0 absolute start-0 z-10"><img src="{{url($report->doctor_profile)}}" alt="" srcset="" class="w-full h-full rounded-full"></div>
                                <div class="w-14 h-14 rounded-full  ms-0 absolute end-0 z-20"><img src="{{url($report->profile_img)}}" alt="" srcset="" class="w-full h-full rounded-full"></div>
                            </div> --}}
                            <div class="">
                                <p class="text-base font-semibold capitalize mb-1">Dr.{{$report->doctor_first_name}} {{$report->doctor_last_name}} - {{$report->patient_first_name}} {{$report->patient_last_name}}</p>
                                <a href="#" class="text-white text-xs font-medium bg-[#0284C7] rounded-full px-3 py-1 ">{{ \Carbon\Carbon::parse($report->appointment_date)->format('d M Y') }} @ {{$report->schedule_time}}</a>
                            </div>
                        </div>
                    </div>
                    <div class="grid grid-cols-2 gap-3 mt-5">
                        <div class="my-1">
                            <p class="font-medium text-gray-400 text-xs">Email</p>
                            <p class="font-semibold  text-sm">{{$report->patient_email}}</p>
                        </div>
                        <div class="my-1">
                            <p class="font-medium text-gray-400 text-xs">Phone</p>
                            <p class="font-semibold  text-sm">+91 {{$report->patient_phone}}</p>
                        </div>
                        <div class="my-1">
                            <p class="font-medium text-gray-400 text-xs">Gender</p>
                            <p class="font-semibold  text-sm">{{$report->patient_last_name}}</p>
                        </div>
                        <div class="my-1">
                            <p class="font-medium text-gray-400 text-xs">Marital Status</p>
                            <p class="font-semibold  text-sm">{{$report->patient_marital_status}}</p>
                        </div>
                        <div class="my-1">
                            <p class="font-medium text-gray-400 text-xs">DOB</p>
                            <p class="font-semibold  text-sm">{{$report->patient_dob}}</p>
                        </div>
                        {{-- <div class="my-1">
                            <p class="font-medium text-gray-400 text-xs">Blood Group</p>
                            <p class="font-semibold  text-sm">{{$report->patient_blood_group}}</p>
                        </div> --}}
                        <div class="col-span-2">
                            <p class="font-medium text-gray-400 text-xs">Address</p>
                            <p class="font-semibold  text-sm">{{$report->patient_address}}</p>
                        </div>
                    </div>
                    <div class="my-5">

                        <div class="my-2">
                                <div class="flex justify-between">
                                    <label for="parameeter" class="font-semibold">Additional Parameters if required</label>
                                    <input type="checkbox" name="" id="parameeter" class="peer hidden">
                                    <div class="w-4 h-4  peer-checked:bg-black peer-checked:border-black rounded-sm text-white flex justify-center items-center border-2 border-gray"><i class="ri-check-line"></i></div>
                                </div>
                        </div>
                        <div class="my-2">
                                <div class="flex justify-between">
                                    <label for="parameeter" class="font-semibold">Additional Parameters if required</label>
                                    <input type="checkbox" name="" id="parameeter" class="peer hidden">
                                    <div class="w-4 h-4  peer-checked:bg-black peer-checked:border-black rounded-sm text-white flex justify-center items-center border-2 border-gray"><i class="ri-check-line"></i></div>
                                </div>
                        </div>
                        <div class="my-2">
                                <div class="flex justify-between">
                                    <label for="parameeter" class="font-semibold">Additional Parameters if required</label>
                                    <input type="checkbox" name="" id="parameeter" class="peer hidden">
                                    <div class="w-4 h-4  peer-checked:bg-black peer-checked:border-black rounded-sm text-white flex justify-center items-center border-2 border-gray"><i class="ri-check-line"></i></div>
                                </div>
                        </div>
                    </div>
                </div>
                @endforeach
                @endif
                <div class="md:col-span-2 lg:col-span-3 p-3">
                    <div class="flex justify-between  bg-white">
                    <h5 class="text-base capitalize font-semibold">&nbsp;Doctor Notes</h5> <a href="add-doctor.html" class="d-inline-block p-2 rounded-md bg-gray-200 text-sm"><i class="ri-download-2-line mt-2"></i>&nbsp;&nbsp;Download note</a>
                </div>
                <p class="p-2 text-sm">Lorem ipsum odor amet, consectetuer adipiscing elit. Cubilia phasellus penatibus justo dolor vel. Ante etiam imperdiet ut odio vel sit pharetra condimentum dui. Ornare egestas facilisi suspendisse odio congue vel. Malesuada volutpat taciti gravida tellus quisque sed interdum phasellus. Magnis rhoncus at facilisis integer aenean morbi sollicitudin semper facilisis. Duis fames arcu mollis hendrerit iaculis curae natoque luctus habitant. Nulla sociosqu nisl nullam suscipit ante egestas fermentum. Nibh iaculis platea platea hac at litora sodales curae elit.</p>
                <p class="p-2 text-sm">Lorem ipsum odor amet, consectetuer adipiscing elit. Cubilia phasellus penatibus justo dolor vel. Ante etiam imperdiet ut odio vel sit pharetra condimentum dui. Ornare egestas facilisi suspendisse odio congue vel. Malesuada volutpat taciti gravida tellus quisque sed interdum phasellus. Magnis rhoncus at facilisis integer aenean morbi sollicitudin semper facilisis. Duis fames arcu mollis hendrerit iaculis curae natoque luctus habitant. Nulla sociosqu nisl nullam suscipit ante egestas fermentum. Nibh iaculis platea platea hac at litora sodales curae elit.</p>
                <p class="p-2 text-sm">Lorem ipsum odor amet, consectetuer adipiscing elit. Cubilia phasellus penatibus justo dolor vel. Ante etiam imperdiet ut odio vel sit pharetra condimentum dui. Ornare egestas facilisi suspendisse odio congue vel. Malesuada volutpat taciti gravida tellus quisque sed interdum phasellus. Magnis rhoncus at facilisis integer aenean morbi sollicitudin semper facilisis. Duis fames arcu mollis hendrerit iaculis curae natoque luctus habitant. Nulla sociosqu nisl nullam suscipit ante egestas fermentum. Nibh iaculis platea platea hac at litora sodales curae elit.</p>
              
              
                    </div>
                   

                </form>
            </div>
            </div>
        </div>
    </div>
   
</body>
@section('script')
@stop
@stop
</html>
