<!DOCTYPE html>
<html>
<head>
    <title>Customer Availability</title>
</head>
<body>
    <p>Dear Admin,</p>
    <p>The customer 
        {{-- <strong>{{ $customerName }}</strong> --}} Rohit
         has submitted their availability details:</p>
    <ul>
        <li><strong>Proposal number:</strong> {{ $data['proposal_number'] }}</li>
        <li><strong>Date:</strong> {{ $data['avalibledate'] }}</li>
        <li><strong>Start Time:</strong> {{ $data['start_time'] }}</li>
        <li><strong>End Time:</strong> {{ $data['end_time'] }}</li>
    </ul>
    <p>Please arrange accordingly.</p>
    <p>Best Regards,</p>
    <p>Your Company</p>
</body>
</html>
