<!DOCTYPE html>
<html>
<head>
    <title>Honest</title>
</head>
<body>
    <h2>New Patient Log Entry</h2>
    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Natus, numquam reprehenderit placeat vel dolorum rem itaque dignissimos perferendis rerum, provident voluptatem deserunt labore exercitationem. Quasi doloribus quibusdam molestias ratione soluta at corporis maxime alias architecto accusantium beatae minima possimus voluptate sapiente debitis deserunt dicta perferendis quis aspernatur nostrum, ipsa ea?</p>
    <p><strong>Name:</strong> {{ $first_name }}</p>
    <p><strong>Email:</strong> {{ $email }}</p>
    <p><strong>Message:</strong> {{ $address }}</p>
 
   <a href="http://127.0.0.1:8000/avalableform/{{$encryptedproposal_number}}">http://127.0.0.1:8000/avalableform/{{$encryptedproposal_number}}</a>
    {{-- <p><strong>Company Email:</strong> {{ $insurance_company_email }}</p> --}}
    {{-- <p><strong>profile:</strong> <img src="{{url($profile_img)}}" alt="" height='200' width='200'></p> --}}
</body>
</html>
