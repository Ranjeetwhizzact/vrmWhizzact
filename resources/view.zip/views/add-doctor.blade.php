@extends('layouts.app')
@section('title','Honest | Home ')
@section('content')
    <div class="flex h-screen divide-x-2 divide-gray-100 ">
        <!-- Sidebar -->
        @include('common.sidenav')
       

        <!-- Main Content -->
        <div class="main-content flex-1 ml-64 transition-all duration-300">
            <!-- Welcome Section -->
           @include('common.header')

            <!-- Table Section -->
          
            <div class="p-5 bg-white">
                @if (session('success'))
                <h5 class="font-md bg-white text-green-500 text text-lg my-2">{{ session('success') }}</h5>
                @else
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
                @endif
                <form action="{{url('/storedoctor')}}" method="POST" enctype="multipart/form-data" accept-charset="UTF-8">
                    @csrf
            <div class="grid md:grid-cols-4 lg:grid-cols-5 gap-4 divide-x">
                <div class="col-span-4 md:col-span-2 lg:col-span-3 p-3">
                        <div class="grid grid-cols-2 gap-4">
                            <div class="col-span-2 ">
                                <div class="text-lg font-semibold  ">Add Doctor</div>
                                <label for="profile" class="border-2 w-24 h-24 rounded-full inline-block my-3"><img src="{{isset($doctor->doctor_img)?$doctor->doctor_img:'assests\img\avatar.png'}}" alt="" srcset=""  class="w-full h-full rounded-full uploadedimg"></label>
                                @if(request()->is('createdoctor'))
                                <input type="file" name="doctor_img" class="w-full border border-gray-300 p-2 rounded-lg hidden" placeholder="John" id="profile" required>
                                @else
                                <input type="file" name="doctor_img" class="w-full border border-gray-300 p-2 rounded-lg hidden" placeholder="John" id="profile">
                                @endif
                            </div>
                            
                            <!-- First Name -->
                            <div class="col-span-2 lg:col-span-1">
                                <input type="hidden" name="id" value="{{isset($doctor->id)?$doctor->id:''}}" class="w-full border border-gray-300 p-2 rounded-lg" placeholder="John">
                                <label class="block text-gray-700 font-mediublock text-gray-700 font-medium mb-2 text-sm">First Name</label>
                                <input type="text" id="" name="first_name" value="{{isset($doctor->first_name)?$doctor->first_name:''}}" class="w-full border border-gray-300 p-2 rounded-lg textInput" placeholder="John" required>
                                <p id="message"></p>
                            </div>
                            <!-- Last Name -->
                            <div class="col-span-2 lg:col-span-1">
                                <label class="block text-gray-700 font-mediublock text-gray-700 font-medium mb-2 text-sm">Last Name</label>
                                <input type="text" id="" name="last_name" value="{{isset($doctor->last_name)?$doctor->last_name:''}}" class="w-full border border-gray-300 p-2 rounded-lg textInput" placeholder="Doe" required>
                            </div>
                            <!-- Email -->
                            <div class="col-span-2 lg:col-span-1">
                                <label class="block text-gray-700 font-mediublock text-gray-700 font-medium mb-2 text-sm">Email </label>
                                <input type="email"  name="email" value="{{isset($doctor->email)?$doctor->email:''}}"  class="w-full border border-gray-300 p-2 rounded-lg email" placeholder="example@email.com" required>
                            </div>
                            <div class="col-span-2 lg:col-span-1">
                                <label class="block text-gray-700 font-mediublock text-gray-700 font-medium mb-2 text-sm"> Username</label>
                                <input type="email"  name="username" value="{{isset($doctor->username)?$doctor->username:''}}"  class="w-full border border-gray-300 p-2 rounded-lg email" placeholder="example@email.com" required>
                            </div>
                            <div class="col-span-2 lg:col-span-1">
                                <label class="block text-gray-700 font-mediublock text-gray-700 font-medium mb-2 text-sm">Password</label>
                                <input type="password" id="" value="" name="password" value="" class="w-full border border-gray-300 p-2 rounded-lg textInput" placeholder="Doe" {{isset($doctor)?'':'required'}}>
                            </div>
                            <!-- Phone -->
                            <div class="col-span-2 lg:col-span-1">
                                <label class="block text-gray-700 font-mediublock text-gray-700 font-medium mb-2 text-sm">Phone</label>
                                <input type="text" name="phone" value="{{isset($doctor->phone)?$doctor->phone:''}}"  class="w-full border border-gray-300 p-2 rounded-lg phone" placeholder="+123456789" required>
                            </div>
                            <!-- Gender -->
                            <div class="col-span-2 lg:col-span-1">
                                <label class="block text-gray-700 font-mediublock text-gray-700 font-medium mb-2 text-sm">Gender</label>
                                <select class="w-full border border-gray-300 p-2 rounded-lg" name="gender">
                                    <option value="male"  {{ isset($doctor->male) && $doctor->male == "male" ? 'selected' : '' }}>Male</option>
                                    <option value="female"  {{ isset($doctor->female) && $doctor->female == "female" ? 'selected' : '' }}>Female</option>
                                    <option value="other"  {{ isset($doctor->gender) && $doctor->gender == "other" ? 'selected' : '' }}>Other</option> 
                                </select>
                            </div>
                            <div class="col-span-2 lg:col-span-1">
                                <label class="block text-gray-700 font-mediublock text-gray-700 font-medium mb-2 text-sm">Education</label>
                                <input type="text" name="education" value="{{isset($doctor->education)?$doctor->education:''}}"  class="w-full border border-gray-300 p-2 rounded-lg phone" placeholder="" required>
                            </div>
                            <div class="col-span-2 lg:col-span-1">
                                <label class="block text-gray-700 font-mediublock text-gray-700 font-medium mb-2 text-sm">Referance Number</label>
                                <input type="text" name="reference_number" value="{{isset($doctor->reference_number)?$doctor->reference_number:''}}"  class="w-full border border-gray-300 p-2 rounded-lg phone" placeholder="Referance Number" required>
                            </div>
                            <div class="col-span-2 lg:col-span-1">
                                <label class="block text-gray-700 font-mediublock text-gray-700 font-medium mb-2 text-sm">Degree</label>
                                <input type="file"  name="degree" value=""  class="w-full border border-gray-300 p-2 rounded-lg phone" placeholder="" >
                            </div>
                     
                            <!-- Address (Full Width) -->
                      
                    
                        </div>
            
                        <!-- Submit Button -->
                        <div class="mt-4 text-centercol-span-2">
                            <button type="submit" class="bg-black text-white px-6 py-2 rounded-lg w-full hover:bg-gray-500">Submit</button>
                        </div>
                    </div>
                    <div class="col-span-4 md:col-span-2 lg:col-span-2  divide-y">
                     <h5 class="px-4 pt-1 pb-2">Availablity</h5>
               
                     <div id="schedule-form">
                        <div id="schedule-fields" class="space-y-4">
                            <!-- Default Sunday Schedule -->
                           @if(request()->is('createdoctor'))
                            <div class="flex items-center justify-between  p-2 rounded-md" id="sunday">
                                <span class="text-gray-700 font-medium w-20">Sunday</span>
                                <input type="time" name="available_days[sunday][start]" class="p-2 border rounded-md w-24">
                                <input type="time" name="available_days[sunday][end]" class="p-2 border rounded-md w-24">
                                <button type="button" class="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600 remove-btn" onclick="removeDay('sunday')">X</button>
                            </div>
                            @else 
                            @php
                            $weekdays = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
                        @endphp
                        
                        @foreach ($weekdays as $day)
                            @php
                                $isAvailable = isset($doctor->available_days[$day]) && !empty($doctor->available_days[$day]['start_time']) && !empty($doctor->available_days[$day]['end_time']);
                            @endphp
                        
                            @if ($isAvailable)
                                @php
                                    $startTime = $doctor->available_days[$day]['start_time'];
                                    $endTime = $doctor->available_days[$day]['end_time'];
                                @endphp
                        
                                <div class="flex items-center justify-between p-2 rounded-md" id="{{ $day }}">
                                    <span class="text-gray-700 font-medium w-20 capitalize">{{ ucfirst($day) }}</span>
                        
                                    <input type="time" name="available_days[{{ $day }}][start]" class="p-2 border rounded-md w-24" value="{{ $startTime }}">
                                    <input type="time" name="available_days[{{ $day }}][end]" class="p-2 border rounded-md w-24" value="{{ $endTime }}">
                        
                                    <button type="button" class="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600 remove-btn" onclick="removeDay('{{ $day }}')">X</button>
                                </div>
                            @endif
                        @endforeach
                                                    @endif
                        </div>
                        <button type="button" id="add-day" class="mt-4 w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700">Add Day</button>
                        <button type="button" class="mt-2 w-full bg-gray-600 text-white py-2 rounded hover:bg-gray-700" onclick="resetSchedule()">Reset All</button>
                        <!-- Submit Button -->
                     </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
   
</body>
@section('script')
<script>
   $('#profile').change(function () {
    const file = this.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function (e) {
            $('.uploadedimg').attr('src', e.target.result);
        };
        reader.readAsDataURL(file);
    }
});
$(function () {
    $("#users-search").autocomplete({
        source: function (request, response) {
            $.ajax({
                url: "/searchuser",
                data: { term: request.term },
                dataType: "json",
                success: function (data) {
                    response($.map(data, function (useremail) {
                        return {
                            label: useremail.email, // Display this in the dropdown
                            value: useremail.email, // Display this in the input
                            id: useremail.id,       // Hidden internal use
                            data: useremail
                        };
                    }));
                },
                error: function (xhr, status, error) {
                    console.error("Error fetching users:", error);
                }
            });
        },
        minLength: 1, // Trigger after 1 character
        select: function (event, ui) {
            $("#user-id").val(ui.item.id);
            // $("#user-info").html(
            //     `<strong>Name:</strong> ${ui.item.data.email}<br>` +
            //     `<strong>ID:</strong> ${ui.item.data.id}`
            // );
        }
    });
});

</script>
@stop
@stop
</html>
