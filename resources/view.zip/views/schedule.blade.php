@extends('layouts.app')
@section('title','Honest | Home ')
@section('content')
    <div class="flex h-screen divide-x-2 divide-gray-100 ">
        <!-- Sidebar -->
        @include('common.sidenav')
       

        <!-- Main Content -->
        <div class="main-content flex-1 ml-64 transition-all duration-300">
            <!-- Welcome Section -->
           @include('common.header')

            <!-- Table Section -->
            <div class="p-5 bg-white">

                @if(session('status') == 'success')
                    <div class="alert alert-success">
                     <h5 class="text-green-500">{{ session('msg') }}</h5>   
                    </div>
                @endif
                            
         <form action="{{url('storeschedule')}}" method="POST" enctype="multipart/form-data" accept-charset="UTF-8">
            <div class="grid grid-cols-1 gap-4 ">
                @csrf
                <div >
                        <div class="w-1/2 m-auto  shadow-md px-4 py-6 rounded-md grid grid-cols-2 gap-4">
                            
                       
                           
                            <!-- Last Name -->
                            {{-- <div class="col-span-2 md:col-span-1">
                                <input type="hidden" name="id" value="{{isset($schedule->id)?$schedule->id:''}}" class="w-full border border-gray-300 p-2 rounded-lg" placeholder="Insurance campany Name">
                                <label class="block text-gray-700 font-mediublock text-gray-700 font-medium mb-2 capitalize text-sm">Insurance campany Name</label>
                                <input type="text" name="company_name" value="{{isset($schedule->company_name)?$schedule->company_name:''}}" class="w-full border border-gray-300 p-2 rounded-lg" placeholder="Insurance campany Name" required>
                            </div> --}}
                            <!-- Email -->
                            {{-- <div class="col-span-2 md:col-span-1">
                                <label class="block text-gray-700 font-mediublock text-gray-700 font-medium mb-2 text-sm capitalize">Policy ID</label>
                                <input type="text" name="policy_id" value="{{isset($schedule->policy_id)?$schedule->policy_id:''}}" class="w-full border border-gray-300 p-2 rounded-lg" placeholder="INS-XXXXXXXX-XX" pattern="^INS-\d{8}-HI$" required>
                            </div> --}}
                            
                          
                            <!-- Blood Group -->
                         
                            <!-- Address (Full Width) -->
                            {{-- <div class="col-span-2 md:col-span-1">
                                <label class="block text-gray-700 font-mediublock text-gray-700 font-medium mb-2 text-sm ">Reason for the Consultation</label>
                                <textarea class="w-full border border-gray-300 p-2 rounded-lg" rows="5" placeholder="Enter Reason for the Consultation" name="reason_consultation">{{isset($schedule->reason_consultation)?$schedule->reason_consultation:''}}</textarea>
                                <div class="mt-3">

                                    <label class="block text-gray-700 font-mediublock text-gray-700 font-medium mb-2 text-sm capitalize">Reason for the Consultation if have any document</label>
                                    <input type="file" name="reason_consultation_docs" class="w-full border border-gray-300 p-2 rounded-lg" placeholder="Documents">
                                </div>
                            </div> --}}
                            {{-- <div class="col-span-2 md:col-span-1">
                                <label class="block text-gray-700 font-mediublock text-gray-700 font-medium mb-2 text-sm ">Existing Medical Conditions</label>
                                <textarea class="w-full border border-gray-300 p-2 rounded-lg" rows="5" placeholder="Enter Existing Medical Conditions" name="existing_medical_conditions">{{isset($schedule->existing_medical_conditions)?$schedule->existing_medical_conditions:''}}</textarea>
                                <div class="mt-3">

                                    <label class="block text-gray-700 font-mediublock text-gray-700 font-medium mb-2 text-sm capitalize">Existing Medical Conditions if have any document</label>
                                    <input type="file" class="w-full border border-gray-300 p-2 rounded-lg" placeholder="Documents" name="existing_medical_conditions_docs">
                                </div>
                            </div> --}}
                            {{-- <div class="col-span-2 md:col-span-1">
                                <label class="block text-gray-700 font-mediublock text-gray-700 font-medium mb-2 text-sm ">Current Medications</label>
                                <textarea class="w-full border border-gray-300 p-2 rounded-lg" rows="5" placeholder="Enter Current Medications" name="current_medications">{{isset($schedule->current_medications)?$schedule->current_medications:''}}</textarea>
                                <div class="mt-3">

                                    <label class="block text-gray-700 font-mediublock text-gray-700 font-medium mb-2 text-sm capitalize" >Current Medications if have any document</label>
                                    <input type="file" class="w-full border border-gray-300 p-2 rounded-lg" name="current_medications_docs" placeholder="Documents">
                                </div>
                            </div> --}}
                            {{-- <div class="col-span-2 md:col-span-1">
                                <label class="block text-gray-700 font-mediublock text-gray-700 font-medium mb-2 text-sm ">Previous Consultations or Treatments</label>
                                <textarea class="w-full border border-gray-300 p-2 rounded-lg" rows="5" placeholder="Enter Previous Consultations or Treatments" name="previous_consultations">{{isset($schedule->previous_consultations)?$schedule->previous_consultations:''}}</textarea>
                                <div class="mt-3">

                                    <label class="block text-gray-700 font-mediublock text-gray-700 font-medium mb-2 text-sm capitalize">Previous Consultations or Treatments if have any document</label>
                                    <input type="file" class="w-full border border-gray-300 p-2 rounded-lg" placeholder="Documents" name="previous_consultations_docs">
                                </div>
                            </div> --}}
                           
                            
                            <div class="col-span-2 ">
                                <h5 class="ps-3 font-medium my-2 "> Schedule Call</h5>
                                <div class="col-span-2 px-2 mb-3">
                                    <label class="block text-gray-700 font-medium mb-2 text-sm">Proposal Number</label>
                                    <input type="text" id="patients-search" name="proposal_number" class="w-full border border-gray-300 p-2 rounded-lg" placeholder="Proposal number" required>
                                    {{-- <div id="patient-info" style="margin-top: 10px;"></div> --}}
                                    <input type="hidden" id="patient-id" name="assign_patient_id">
                                </div>
                                
                                <div class="px-2">
                                    <label class="font-medium ps-2 text-sm inline-block w-full my-2">Appoint Patient</label>
                                    <input type="text" id="assign_patient_name" class="w-full border border-gray-300 p-2 rounded-lg" name="assign_patient_name" placeholder="Search Patient">
                                </div>
                                
                            </div>

                            <div class="col-span-2">
                                <div class="px-2">
                                    <label for="" class="font-medium ps-2 text-sm inline-block w-full my-2">Appointment Date</label>
                                   
                                        <p> <input type="text" id="date" name="appointment_date" id="datepicker" value="{{isset($schedule->appointment_date)?$schedule->appointment_date:''}}" class="w-full border border-gray-300 p-2 rounded-lg"></p>
                            
                                  
                                   </div>
                                
                            </div>
                            <div class="col-span-2 ">
                                <div class="p-3">
                                    <h5 class="font-medium text-sm">Appointment Time Slot</h5>
                                    <div class="grid grid-cols-2 md:grid-cols-3 gap-2 mt-3">
                                        <div>
                                            <input type="radio" name="appointment_time_slot" id="time" value="09:45" class="time-radiobutton peer hidden">
                                            <label for="time" class="block peer-checked:bg-red-500 peer-checked:text-white bg-red-100 text-sm py-2 px-3 rounded-md text-red-500 w-full text-center cursor-pointer">9:45 AM</label>
                                        </div>
                                        <div>
                                            <input type="radio" name="appointment_time_slot" id="time1" value="10:15" class="time-radiobutton peer hidden">
                                            <label for="time1" class="block peer-checked:bg-red-500 peer-checked:text-white bg-red-100 text-sm py-2 px-3 rounded-md text-red-500 w-full text-center cursor-pointer">10:15 AM</label>
                                        </div>
                                        <div>
                                            <input type="radio" name="appointment_time_slot" id="time2" value="11:45" class="time-radiobutton peer hidden">
                                            <label for="time2" class="block peer-checked:bg-red-500 peer-checked:text-white bg-red-100 text-sm py-2 px-3 rounded-md text-red-500 w-full text-center cursor-pointer">11:45 AM</label>
                                        </div>
                                        <div>
                                            <input type="radio" name="appointment_time_slot" id="time3" value="12:15" class="time-radiobutton peer hidden">
                                            <label for="time3" class="block peer-checked:bg-red-500 peer-checked:text-white bg-red-100 text-sm py-2 px-3 rounded-md text-red-500 w-full text-center cursor-pointer">12:15 PM</label>
                                        </div>
                                        <div>
                                            <input type="radio" name="appointment_time_slot" id="time4" value="13:00" class="time-radiobutton peer hidden">
                                            <label for="time4" class="block peer-checked:bg-red-500 peer-checked:text-white bg-red-100 text-sm py-2 px-3 rounded-md text-red-500 w-full text-center cursor-pointer">01:00 PM</label>
                                        </div>
                                        <div>
                                            <input type="radio" name="appointment_time_slot" id="time5" value="14:30" class="time-radiobutton peer hidden">
                                            <label for="time5" class="block peer-checked:bg-red-500 peer-checked:text-white bg-red-100 text-sm py-2 px-3 rounded-md text-red-500 w-full text-center cursor-pointer">2:30 PM</label>
                                        </div>
                                        <div>
                                            <input type="radio" name="appointment_time_slot" id="time6" value="15:00" class="time-radiobutton peer hidden">
                                            <label for="time6" class="block peer-checked:bg-red-500 peer-checked:text-white bg-red-100 text-sm py-2 px-3 rounded-md text-red-500 w-full text-center cursor-pointer">3:00 PM</label>
                                        </div>
                                        <div>
                                            <input type="radio" name="appointment_time_slot" id="time7" value="15:40" class="time-radiobutton peer hidden">
                                            <label for="time7" class="block peer-checked:bg-red-500 peer-checked:text-white bg-red-100 text-sm py-2 px-3 rounded-md text-red-500 w-full text-center cursor-pointer">3:40 PM</label>
                                        </div>
                                        <div>
                                            <input type="radio" name="appointment_time_slot" id="time8" value="16:10" class="time-radiobutton peer hidden">
                                            <label for="time8" class="block peer-checked:bg-red-500 peer-checked:text-white bg-red-100 text-sm py-2 px-3 rounded-md text-red-500 w-full text-center cursor-pointer">4:10 PM</label>
                                        </div>
                                        <div>
                                            <input type="radio" name="appointment_time_slot" id="time9" value="16:45" class="time-radiobutton hidden  peer">
                                            <label for="time9" class="block peer-checked:bg-red-500 peer-checked:text-white bg-red-100 text-sm py-2 px-3 rounded-md text-red-500 w-full text-center cursor-pointer">4:45 PM</label>
                                        </div>
                                    </div>
                                    
                                    
                                   </div>
                                  
                            </div>
                          
                            <div class="col-span-2">
                            
                                <div class="px-2">
                                 <label for="" class="font-medium ps-2 text-sm inline-block w-full my-2">Appoint Doctor</label>
                                 <select id="doctorSelect" class="py-2 border rounded-md w-full" name="appoint_doctor">
                                    <option value="">Choose Doctor</option>
                                </select>
                                </div>
                                
                                <div class="mt-4 text-centercol-span-2 hidden md:block">
                                    <button type="submit" class="bg-black text-white px-6 py-2 rounded-lg  hover:bg-gray-500">Submit</button>
                                </div>
                            </div>
                        </div>
            
                        <!-- Submit Button -->
                    </div>
                   
            </form>
            <form >
                {{-- <label for="date">Select Date:</label>
                <input type="date" id="date" name="date"><br><br> --}}
            
                {{-- <label>Select Available Time Slots:</label><br>
                <input type="checkbox" class="time-checkbox" value="09:00"> 09:00 AM<br>
                <input type="checkbox" class="time-checkbox" value="12:30"> 12:30 AM<br>
                <input type="checkbox" class="time-checkbox" value="19:50"> 19:50 PM<br>
                <input type="checkbox" class="time-checkbox" value="19:00"> 07:00 PM<br> --}}
                
                <br>
                
{{--             
                <h3>Available Doctors:</h3>
                <div id="result"></div> --}}
            
            </form>
            </div>
        </div>
    </div>
   
</body>
@section('script')
<script>
$(function() {
    function fetchPatientByProposal(proposalNumber) {
        $.ajax({
            url: "/searchpatients",
            type: "GET",
            data: { proposal_number: proposalNumber },
            dataType: "json",
            success: function(data) {
                if (data && data.length > 0) {
                    let selectedPatient = data.find(patient => patient.proposal_number === proposalNumber);

                    if (selectedPatient) {
                        $("#patient-id").val(selectedPatient.id);
                        $("#assign_patient_name").val(selectedPatient.first_name + " " + selectedPatient.last_name);
                        $("#patients-search").val(selectedPatient.proposal_number);
                    } else {
                        console.log("No matching patient found.");
                    }
                } else {
                    console.log("No patient data returned.");
                }
            },
            error: function(xhr, status, error) {
                console.log("AJAX Error:", error);
            }
        });
    }

    $("#patients-search").autocomplete({
        source: function(request, response) {
            $.ajax({
                url: "/searchpatients",
                type: "GET",
                data: { term: request.term },
                dataType: "json",
                success: function(data) {
                    response($.map(data, function(patient) {
                        return {
                            label: patient.proposal_number,
                            value: patient.proposal_number,
                            id: patient.id,
                            data: patient
                        };
                    }));
                },
                error: function(xhr, status, error) {
                    console.log("AJAX Error:", error);
                }
            });
        },
        minLength: 1,
        select: function(event, ui) {
            fetchPatientByProposal(ui.item.value);
        }
    });

    $("#assign_patient_name").autocomplete({
        source: function(request, response) {
            $.ajax({
                url: "/searchpatients",
                type: "GET",
                data: { term: request.term },
                dataType: "json",
                success: function(data) {
                    response($.map(data, function(patient) {
                        return {
                            label: patient.first_name + " " + patient.last_name,
                            value: patient.proposal_number,
                            id: patient.id,
                            data: patient
                        };
                    }));
                },
                error: function(xhr, status, error) {
                    console.log("AJAX Error:", error);
                }
            });
        },
        minLength: 1,
        select: function(event, ui) {
            fetchPatientByProposal(ui.item.value);
        }
    });
});


 $( function() {
        $( "#date" ).datepicker();
      } );

      $(document).ready(function () {
                $('.time-radiobutton').change(function (event) {
                    event.preventDefault(); // Prevent page reload
    
                    let date = $('#date').val();
                    let selectedTimes = [];
    
                    // Get all checked time checkboxes
                    $('.time-radiobutton:checked').each(function () {
                        selectedTimes.push($(this).val());
                    });
    
                    // Debugging alert
                    // alert("Date: " + date + " | Selected Times: " + selectedTimes.join(", "));
    
                    if (!date || selectedTimes.length === 0) {
                        // alert("Please select both a date and at least one time.");
                        $('#result').html('<p style="color: red;">Please select a date and time.</p>');
                        return;
                    }
                    $.ajax({
        url: "{{ route('check.availability') }}",
        method: "POST",
        data: {
            date: date,
            times: selectedTimes, // Send multiple times as an array
            _token: "{{ csrf_token() }}"
        },
        beforeSend: function () {
            // alert("Sending request to server...");
        },
        success: function (response) {
            // alert("Response received from server!");
            console.log("Server Response:", response);
    
            let resultDiv = $('#result');
            resultDiv.empty();
    
            let doctorSelect = $('#doctorSelect'); // Target the dropdown
            doctorSelect.empty(); // Clear previous options
            doctorSelect.append(`<option value="">Choose Doctor</option>`); // Default option
    
            if (response.length > 0) {
                // alert("Doctors Available: " + response.length);
    
                response.forEach(function (doctor) {
                    let option = `<option value="${doctor.id}">${doctor.first_name} ${doctor.last_name}</option>`;
                    doctorSelect.append(option);
                });
    
                resultDiv.append('<p style="color: green;">Doctors available. Please select from the dropdown.</p>');
            } else {
                // alert("No doctors available.");
                resultDiv.append('<p style="color: red;">No doctors available for the selected time.</p>');
            }
        },
        error: function (xhr, status, error) {
            console.log(xhr.responseText);
            // alert("Something went wrong: " + xhr.responseText);
        }
    });
                });
            });
    

</script>
@stop
@stop
</html>
