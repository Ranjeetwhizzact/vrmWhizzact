<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Responsive Date & Time Form</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-timepicker/1.10.0/jquery.timepicker.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-timepicker/1.10.0/jquery.timepicker.min.css">
    <script>
        $(document).ready(function() {
            $("#start-date").datepicker({ dateFormat: 'yy-mm-dd' });
            $("#start-time, #end-time").timepicker({ 'timeFormat': 'H:i' });
        });
    </script>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="flex items-center justify-center min-h-screen bg-gray-100">
    <div class="bg-white p-6 rounded-lg shadow-lg max-w-lg w-full">
        <h2 class="text-xl font-semibold mb-4">Select Start Date-Time</h2>
        {{-- {{$decryptedEmail}} --}}
        @if(session('success'))
    <div class="alert alert-success">
        <h5 class="text-green-600 text-lg">

            {{ session('success') }}
        </h5>
    </div>
   
@endif
        <form action="{{url('/customermail')}}" method="POST" enctype="multipart/form-data" accept-charset="UTF-8" class="col-span-4">
            @csrf
        
          <input type="hidden" name="proposal_number" value="{{$emailId}}">
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700">Start Date</label>
                <input type="text" id="avalibledate" name="avalibledate" class="mt-1 p-2 w-full border rounded-md focus:ring-blue-500 focus:border-blue-500" placeholder="YYYY-MM-DD">
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700">Start Time</label>
                <input type="text" name="start_time" id="start-time" class="mt-1 p-2 w-full border rounded-md focus:ring-blue-500 focus:border-blue-500" placeholder="HH:MM">
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700">To Time</label>
                <input type="text" id="end-time" name="end_time" class="mt-1 p-2 w-full border rounded-md focus:ring-blue-500 focus:border-blue-500" placeholder="HH:MM">
            </div>
            <button type="submit" class="w-full bg-black text-white p-2 rounded-md hover:bg-gray-700">Submit</button>
        </form>
    </div>
</body>
</html>
